clear all;
clear run_data_viewer;
%%
global delta_t;
global traj;
global servo_time_stamps;
global way_points;
global rudder_servo_signal;
global throtle_servo_signal;
global rc_signal_time_stamps;
global rc_rudder_signal;
global rc_throtle_signal;
%%
global max_n_servo_signal
global max_n_delta_t
global max_n_trj
global max_n_rc_signal;
global enable_live_view;
global use_absolute_pos;
global ax_bird_view;
global ax_control_loop_period;
global ax_rc_remocon_signal;
global ax_servo_control_signal;
global aggregate_way_points;
global update_cnt_period;
update_cnt_period = 20;
max_n_servo_signal = 0;
max_n_delta_t = 0;
max_n_trj = 0; % 0 : every trajectory, > 0 : plot only max_n_trj trajectories
max_n_rc_signal = 0;
enable_live_view = 0;
use_absolute_pos = 0;
aggregate_way_points = 1;
%%
figure(1); clf;
ax_bird_view = gca;
set(gcf,'Color',[1 1 1]);
figure(2); clf;
ax_control_loop_period = gca;
set(gcf,'Color',[1 1 1]);
figure(3); clf;
ax_rc_remocon_signal = gca;
set(gcf,'Color',[1 1 1]);
figure(4); clf;
ax_servo_control_signal = gca;
set(gcf,'Color',[1 1 1]);
autoArrangeFigures(2,3,2);
%%
file_dir = 'fieldtest4';
log_file = '20170110164520.txt';
s = fopen(strcat(file_dir, '/', log_file),'r');
f_dummy = fopen('dummy_log.txt','w');
finishup1 = onCleanup(@() fclose(s));
finishup2 = onCleanup(@() fclose(f_dummy));
try
    run_data_viewer(s, f_dummy);
catch
    warning('data_viewer aborted')
end
%%
fclose(s);
fclose(f_dummy);